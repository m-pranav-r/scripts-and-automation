function onCreated() {
  if (browser.runtime.lastError) {
    console.log(`Error: ${browser.runtime.lastError}`);
  } else {
    console.log("Item created successfully");
  }
}

browser.contextMenus.create(
  {
    id: "decode-selection",
    title: "Decode with Base64",
    contexts: ["selection"]
  }, onCreated
);

function decodeFromBase64(text) {
  return atob(text);
}

browser.contextMenus.onClicked.addListener((info, tab) => {
  console.log("Menu event generated.");
  switch(info.menuItemId) {
    case "decode-selection":
      let decodedText = decodeFromBase64(info.selectionText);
      document.querySelector('encoded > p').innerHTML = text;
      document.querySelector('decoded > p').innerHTML = decodedText;
      console.log(decodedText);
      break;
  }
});
